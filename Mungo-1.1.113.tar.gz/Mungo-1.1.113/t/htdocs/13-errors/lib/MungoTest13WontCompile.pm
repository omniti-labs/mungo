package MungoTest13WontCompile;
use strict;
use warnings;

=pod

Marker text to indicate that the source of the test module is displayed.

=cut

$foo = 1; # undeclared variable, use strict in effect

1;
